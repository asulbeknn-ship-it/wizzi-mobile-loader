package com.wizzi

import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.content.FileProvider
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class DownloadService : Service() {
  companion object {
    private const val APK_URL = "https://example.com/app.apk"
    private const val APK_NAME = "wizzi_app.apk"
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Thread {
      downloadAndInstall()
    }.start()
    return START_STICKY
  }

  private fun downloadAndInstall() {
    try {
      sendUpdate(0, getString(R.string.checking_connection))

      val url = URL(APK_URL)
      val connection = url.openConnection()
      connection.connect()

      val fileLength = connection.contentLength
      val input = connection.getInputStream()

      val outputFile = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), APK_NAME)
      val output = FileOutputStream(outputFile)

      val data = ByteArray(4096)
      var total: Long = 0
      var count: Int

      sendUpdate(5, getString(R.string.launching_launcher))

      while (input.read(data).also { count = it } != -1) {
        total += count
        output.write(data, 0, count)
        val progress = (total * 100 / fileLength).toInt()
        sendUpdate(progress, "Downloading: $progress%")
      }

      output.close()
      input.close()

      sendUpdate(95, getString(R.string.launching_launcher))
      installAPK(outputFile)
      sendUpdate(100, getString(R.string.launching_launcher))

    } catch (e: Exception) {
      sendUpdate(0, getString(R.string.error_download_failed))
    }
  }

  private fun installAPK(file: File) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
      val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        FileProvider.getUriForFile(this@DownloadService, "${packageName}.fileprovider", file)
      } else {
        Uri.fromFile(file)
      }
      setDataAndType(uri, "application/vnd.android.package-archive")
      flags = Intent.FLAG_ACTIVITY_NEW_TASK
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    startActivity(intent)
  }

  private fun sendUpdate(progress: Int,