package com.wizzi

import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class MainActivity : AppCompatActivity() {
  private lateinit var downloadButton: Button
  private lateinit var progressBar: ProgressBar
  private lateinit var statusText: TextView
  private lateinit var downloadReceiver: DownloadReceiver

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    downloadButton = findViewById(R.id.downloadButton)
    progressBar = findViewById(R.id.downloadProgress)
    statusText = findViewById(R.id.statusText)

    downloadReceiver = DownloadReceiver { progress, status ->
      updateUI(progress, status)
    }

    downloadButton.setOnClickListener {
      startDownload()
    }
  }

  private fun startDownload() {
    statusText.text = getString(R.string.checking_connection)
    val intent = Intent(this, DownloadService::class.java)
    startService(intent)
    downloadButton.isEnabled = false
  }

  private fun updateUI(progress: Int, status: String) {
    progressBar.progress = progress
    statusText.text = status
    if (progress == 100) {
      downloadButton.isEnabled = true
    }
  }

  override fun onStart() {
    super.onStart()
    val filter = IntentFilter("com.wizzi.DOWNLOAD_UPDATE")
    LocalBroadcastManager.getInstance(this).registerReceiver(downloadReceiver, filter)
  }

  override fun onStop() {
    super.onStop()
    LocalBroadcastManager.getInstance(this).unregisterReceiver(downloadReceiver)
  }
}
