package com.wizzi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DownloadReceiver(val onUpdate: (Int, String) -> Unit) : BroadcastReceiver() {
  override fun onReceive(context: Context?, intent: Intent?) {
    val progress = intent?.getIntExtra("progress", 0) ?: 0
    val status = intent?.getStringExtra("status") ?: ""
    onUpdate(progress, status)
  }
}
