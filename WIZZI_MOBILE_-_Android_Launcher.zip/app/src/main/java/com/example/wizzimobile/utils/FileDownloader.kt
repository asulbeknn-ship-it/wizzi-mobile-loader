package com.example.wizzimobile.utils

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class FileDownloader(private val context: Context) {
  fun downloadFile(
    url: String,
    fileName: String,
    onProgress: (Int) -> Unit,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
  ) {
    GlobalScope.launch(Dispatchers.IO) {
      try {
        val connection = URL(url).openConnection()
        val contentLength = connection.contentLength

        if (contentLength == -1) {
          throw Exception("Cannot determine file size")
        }

        val inputStream = connection.inputStream
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val file = File(downloadsDir, fileName)

        FileOutputStream(file).use { fos ->
          val buffer = ByteArray(8192)
          var bytesRead = 0
          var totalBytesRead = 0L

          while (inputStream.read(buffer).also { bytesRead = it } != -1) {
            fos.write(buffer, 0, bytesRead)
            totalBytesRead += bytesRead
            val progress = ((totalBytesRead * 100) / contentLength).toInt()
            onProgress(progress)
          }
        }

        inputStream.close()
        onSuccess()
      } catch (e: Exception) {
        onError(e.message ?: "Unknown error")
      }
    }
  }
}
  