package com.example.wizzimobile

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.wizzimobile.utils.FileDownloader

class MainActivity : AppCompatActivity() {
  private lateinit var downloadButton: Button
  private lateinit var progressBar: ProgressBar
  private lateinit var statusText: TextView
  private lateinit var fileDownloader: FileDownloader

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)

    downloadButton = findViewById(R.id.downloadButton)
    progressBar = findViewById(R.id.progressBar)
    statusText = findViewById(R.id.statusText)

    fileDownloader = FileDownloader(this)

    downloadButton.setOnClickListener {
      downloadFile()
    }
  }

  private fun downloadFile() {
    downloadButton.isEnabled = false
    progressBar.visibility = android.view.View.VISIBLE
    statusText.visibility = android.view.View.VISIBLE
    statusText.text = "Downloading..."

    fileDownloader.downloadFile(
      "https://example.com/file.zip",
      "Downloaded_File.zip",
      onProgress = { progress ->
        progressBar.progress = progress
        statusText.text = "Downloading... $progress%"
      },
      onSuccess = {
        progressBar.visibility = android.view.View.GONE
        statusText.text = "Download completed!"
        statusText.setTextColor(getColor(R.color.success))
        downloadButton.isEnabled = true
      },
      onError = { error ->
        progressBar.visibility = android.view.View.GONE
        statusText.text = "Error: $error"
        statusText.setTextColor(getColor(R.color.error))
        downloadButton.isEnabled = true
      }
    )
  }
}
  